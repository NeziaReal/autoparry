---@type Action
local Action = getfenv().Action

---Module function.
---@param self AnimatorDefender
---@param timing AnimationTiming
return function(self, timing)
	local distance = self:distance(self.entity)

	local action = Action.new()
	action._when = math.min(600 + distance * 1, 1300)
	action._type = "Parry"
	action.hitbox = Vector3.new(15, 15, 40)
	action.name = string.format("(%.2f) Dynamic Gin Crit Timing", distance)

	return self:action(timing, action)
end
