---@type Action
local Action = getfenv().Action

---Module function.
---@param self AnimatorDefender
---@param timing AnimationTiming
return function(self, timing)
	local distance = self:distance(self.entity)

	local action = Action.new()
	action._when = math.min(690 + distance * 2.5, 1200)
	action._type = "Parry"
	action.hitbox = Vector3.new(100, 30, 120)
	action.name = string.format("(%.2f) Dynamic Delayed Death Timing", distance)

	return self:action(timing, action)
end
